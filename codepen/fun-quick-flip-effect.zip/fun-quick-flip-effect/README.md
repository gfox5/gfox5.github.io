# Fun "quick flip" effect

A Pen created on CodePen.

Original URL: [https://codepen.io/kevinpowell/pen/ZYzNjbX](https://codepen.io/kevinpowell/pen/ZYzNjbX).

I saw this effect added to the Motion examples, which uses duplicate text (with the duplicate using aria-hidden). I wanted to see if I could do it without duplicating the text.

https://bsky.app/profile/citizenofnowhe.re/post/3lheakt2msc2d
https://examples.motion.dev/react/text-reveal