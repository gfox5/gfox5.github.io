# Animated Digital Clock (React)

A Pen created on CodePen.

Original URL: [https://codepen.io/chrisgannon/pen/pvomdpB](https://codepen.io/chrisgannon/pen/pvomdpB).

I designed a set of numerals made from just two rectangles to create the numeral using negative space.